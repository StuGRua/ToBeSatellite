package Menu;


/* *
 * @Author 朝喜
 * @Description 启动，主函数
 * @Date  2020-8-5
 **/

public class Start {
    public static void main(String[] args) {
        MainMenu menu = new MainMenu();
        menu.menu();
    }
}
