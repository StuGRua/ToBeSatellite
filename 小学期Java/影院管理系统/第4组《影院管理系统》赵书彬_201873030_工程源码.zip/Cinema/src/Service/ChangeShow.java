package Service;

/* *
 * @Author StuG
 * @Description 放映接口：管理员添加、删除、修改场次
 * @Date  2020-8-5
 **/

public interface ChangeShow {
    void AddShow();

    void DelShow();

    void ChangeShow();
}
