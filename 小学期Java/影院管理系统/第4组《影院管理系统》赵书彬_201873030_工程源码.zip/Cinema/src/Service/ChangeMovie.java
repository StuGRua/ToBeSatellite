package Service;

/* *
 * @Author StuG
 * @Description 影片接口：管理员添加、删除影片
 * @Date  2020-8-5
 **/

public interface ChangeMovie {
    void AddMovie();

    void DelMovie();
}
