# Cinema
CinemaManageSystem - Java in 3rd term of 2019-2020 school year
---
* Detail：ide使用IDEA，数据库使用mysql5.7
* Author：赵书彬+刘晨欣
* Description：影院管理系统
* Date：2020-8-30

